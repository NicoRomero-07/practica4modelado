package Ejc1.Pack1;

public class X {

    public X(){

    }
    public void rutina1(){
        System.out.println("rutina1");
    }

    protected void rutina2(double y){
        System.out.println("rutina2");
    }

    protected boolean rutina3(int i){
        System.out.println("rutina3");
        return true;
    }

    private int rutina4(){
        System.out.println("rutina4");
        return 0;
    }
}
