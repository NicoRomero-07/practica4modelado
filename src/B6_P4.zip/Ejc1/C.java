package Ejc1;

public class C {
}
