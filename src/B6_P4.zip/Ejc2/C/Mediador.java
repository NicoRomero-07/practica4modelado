package Ejc2.C;

public interface Mediador {
    void abrir(String e);
    void cerrar(String e);

    void cambio();
}
