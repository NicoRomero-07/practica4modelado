package Ejc2.A;

import Ejc1.A;
import Ejc1.B;
import Ejc1.C;
import Ejc1.Pack1.Proxy;
import Ejc1.Pack1.X;

public class Prueba {
    public static void main (String [ ] args) {

    }
}
