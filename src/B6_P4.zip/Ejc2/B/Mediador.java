package Ejc2.B;

public interface Mediador {
    void abrir(String e);
    void cerrar(String e);


}
