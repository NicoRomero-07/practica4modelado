package Ejc2.B;

public class Biestable extends Estable{
    public Biestable(){
        super();
    }
}
