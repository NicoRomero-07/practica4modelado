package Ejc2.B;

public class Triestable extends Estable{
    public Triestable(){
        super();
    }
}
