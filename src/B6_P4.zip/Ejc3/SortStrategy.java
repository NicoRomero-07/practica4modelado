package Ejc3;

public interface SortStrategy {
    boolean before(Email m1, Email m2);
}
